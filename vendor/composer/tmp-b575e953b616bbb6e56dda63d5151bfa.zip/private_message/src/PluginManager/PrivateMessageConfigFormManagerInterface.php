<?php

namespace Drupal\private_message\PluginManager;

/**
 * Plugin Manager to detect PrivateMessageConfigForm plugins.
 */
interface PrivateMessageConfigFormManagerInterface {}
