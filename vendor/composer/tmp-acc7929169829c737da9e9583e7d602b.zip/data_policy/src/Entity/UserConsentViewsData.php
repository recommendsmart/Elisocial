<?php

namespace Drupal\data_policy\Entity;

use Drupal\views\EntityViewsData;

/**
 * Provides Views data for User Consent entities.
 */
class UserConsentViewsData extends EntityViewsData {

}
