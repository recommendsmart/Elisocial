<?php

namespace Drupal\data_policy\Entity;

use Drupal\views\EntityViewsData;

/**
 * Provides Views data for Data policy entities.
 */
class DataPolicyViewsData extends EntityViewsData {

}
