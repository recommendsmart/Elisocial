<?php

namespace Drupal\symfony_mailer\Exception;

/**
 * Error thrown when no email transport is configured.
 */
class MissingTransportException extends \Exception {

}
