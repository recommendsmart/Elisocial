<?php

/**
 * @file
 * Post update functions for Views.
 */

/**
 * Clear caches to fix Update Helper services.
 */
function update_helper_post_update_fix_services() {
  // Empty post-update hook.
}
