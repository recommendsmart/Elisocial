$(document).ready(function() {

  // Attach autosize listener.
  autosize($('.form-control--autogrow'));

});