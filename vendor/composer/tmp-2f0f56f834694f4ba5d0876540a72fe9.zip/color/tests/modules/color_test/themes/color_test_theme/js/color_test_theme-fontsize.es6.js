/**
 * @file
 * Adds javascript functions for font resizing.
 */
(function ($) {
  $(document).ready(() => {});
})(jQuery);
